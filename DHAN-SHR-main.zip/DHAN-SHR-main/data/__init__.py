from .data_RGB import get_training_data, get_validation_data
